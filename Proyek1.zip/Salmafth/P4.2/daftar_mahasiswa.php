<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Bootstrap 4, from LayoutIt!</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

  </head>
  <body>
    <div class="container-fluid">
	<div class="row">
		<div class="col-md-12 flex-row">
			<nav class="navbar navbar-expand-lg navbar-light bg-light">
				<a class="navbar-brand" href="#">WEB02</a>
				<div class="navbar-collapse collapse show" id="bs-example-navbar-collapse-1">
					<ul class="navbar-nav">
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown">Review PHP</a>
							<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
							</div>
						</li>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown">PHP5 OOP</a>
							<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
							</div>
						</li>
					</ul>
					<form class="form-inline">
						<input class="form-control mr-sm-2" type="text"> 
						<button class="btn btn-primary my-2 my-sm-0" type="submit">
							Submit
						</button>
					</form>
					<ul class="navbar-nav ml-md-auto">
						<li class="nav-item active">
							 <a class="nav-link" href="#">Login<span class="sr-only">(current)</span></a>
						</li>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown">Dropdown</a>
							<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
							</div>
						</li>
					</ul>
				</div>
			</nav>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="d-flex" style="margin-top : 10px;">
				<div class="col-md-6">
					<div class="form-group row">
						<label for="select" class="">Show</label> 
						<div class="col-8">
						<select id="select" name="select">
							<option value="1">10</option>
							<option value="5">15</option>
							<option value="10">20</option>
						</select> entries
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="row justify-content-end">
						<label for="search">Search :</label>
						<input type="text">
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<table class="table">
				<thead>
					<tr>
						<th>No</th>
						<th>NIM</th>
						<th>Nama</th>
						<th>Prodi</th>
						<th>Thn Angkatan</th>
						<th>IPK</th>
						<th>Predikat</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<tr class="table-active">
						<td>1</td>
						<?php 
							require_once ('class_mahasiswa.php');

							$mahasiswa = new Mahasiswa(272, 'salma', 'SI', 2021, 3);

							echo '<td>'.$mahasiswa->nim.'</td>';
							echo '<td>'.$mahasiswa->nama.'</td>';
							echo '<td>'.$mahasiswa->prodi.'</td>';
							echo '<td>'.$mahasiswa->thn_angkatan.'</td>';
							echo '<td>'.$mahasiswa->ipk.'</td>';
							echo '<td>'.$mahasiswa->predikat_ipk().'</td>';
						
						?>
						<td></td>
					</tr>
					<tr class="table-success">
						<td>2</td>
						<?php 
							require_once ('class_mahasiswa.php');

							$mahasiswa = new Mahasiswa(122, 'sabrina', 'TI', 2021, 3.5);

							echo '<td>'.$mahasiswa->nim.'</td>';
							echo '<td>'.$mahasiswa->nama.'</td>';
							echo '<td>'.$mahasiswa->prodi.'</td>';
							echo '<td>'.$mahasiswa->thn_angkatan.'</td>';
							echo '<td>'.$mahasiswa->ipk.'</td>';
							echo '<td>'.$mahasiswa->predikat_ipk().'</td>';
						
						?>
						<td></td>
					</tr>
					<tr class="table-warning">
						<td>3</td>
						<?php 
							require_once ('class_mahasiswa.php');

							$mahasiswa = new Mahasiswa(123, 'nisa', 'TI', 2021, 2.6);

							echo '<td>'.$mahasiswa->nim.'</td>';
							echo '<td>'.$mahasiswa->nama.'</td>';
							echo '<td>'.$mahasiswa->prodi.'</td>';
							echo '<td>'.$mahasiswa->thn_angkatan.'</td>';
							echo '<td>'.$mahasiswa->ipk.'</td>';
							echo '<td>'.$mahasiswa->predikat_ipk().'</td>';
						
						?>
						<td></td>
					</tr>
					<tr class="table-danger">
						<td>4</td>
						<?php 
							require_once ('class_mahasiswa.php');

							$mahasiswa = new Mahasiswa(268, 'nailah', 'SI', 2021, 2);

							echo '<td>'.$mahasiswa->nim.'</td>';
							echo '<td>'.$mahasiswa->nama.'</td>';
							echo '<td>'.$mahasiswa->prodi.'</td>';
							echo '<td>'.$mahasiswa->thn_angkatan.'</td>';
							echo '<td>'.$mahasiswa->ipk.'</td>';
							echo '<td>'.$mahasiswa->predikat_ipk().'</td>';
						
						?>
						<td></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12 d-flex">
			<div class="col-md-6">
				Showing 1 to 4 of entries
			</div>
			<div class="pagination-sm col-md-6">
				<ul class="pagination justify-content-end">
					<li class="page-item">
						<a class="page-link" href="#">Previous</a>
					</li>
					<li class="page-item">
						<a class="page-link" href="#">1</a>
					</li>
					<li class="page-item">
						<a class="page-link" href="#">Next</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<hr>
	<div class="row">
		<div class="col-md-12">
			<address>
				 <strong>Lab Pemrograman Web Lanjutan</strong>
				 <br> Dosen: Sirojul Munir S.Si,M.Kom
				 <br> STT-NF - Kampus B
			</address>
		</div>
	</div>
</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
  </body>
</html>