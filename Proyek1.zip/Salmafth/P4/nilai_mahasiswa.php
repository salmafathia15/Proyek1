<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Bootstrap 4, from LayoutIt!</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

  </head>
  <body>
	  <!-- header -->
    <div class="container-fluid">
	<div class="row">
		<div class="col-md-12 flex-row">
			<nav class="navbar navbar-expand-lg navbar-light bg-light">
				<a class="navbar-brand" href="#">WEB02</a>
				<div class="navbar-collapse collapse show" id="bs-example-navbar-collapse-1">
					<ul class="navbar-nav">
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown">Review PHP</a>
							<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
							</div>
						</li>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown">PHP5 OOP</a>
							<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
							</div>
						</li>
					</ul>
					<form class="form-inline">
						<input class="form-control mr-sm-2" type="text"> 
						<button class="btn btn-primary my-2 my-sm-0" type="submit">
							Submit
						</button>
					</form>
					<ul class="navbar-nav ml-md-auto">
						<li class="nav-item active">
							 <a class="nav-link" href="#">Login<span class="sr-only">(current)</span></a>
						</li>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown">Dropdown</a>
							<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
							</div>
						</li>
					</ul>
				</div>
			</nav>
		</div>
	</div>
	<!-- main content -->
	<form style="margin-top : 15px;" method="GET" action="nilai_mahasiswa.php" autocomplete="off">
		<div class="form-group row">
			<label for="text" class="col-4 col-form-label">NIM</label> 
			<div class="col-8">
			<input id="text" name="nim" type="text" class="form-control">
			</div>
		</div>
		<div class="form-group row">
			<label for="select" class="col-4 col-form-label">Pilih MK</label> 
			<div class="col-8">
			<select id="select" name="matkul" class="custom-select">
				<option value="Basis Data">Basis Data</option>
				<option value="Pemrograman Web">Pemrograman Web</option>
				<option value="PPKN">PPKN</option>
			</select>
			</div>
		</div>
		<div class="form-group row">
			<label for="text2" class="col-4 col-form-label">Nilai</label> 
			<div class="col-8">
			<input id="text2" name="nilai" type="text" class="form-control">
			</div>
		</div> 
		<div class="form-group row">
			<div class="offset-4 col-8">
			<button name="submit" type="submit" class="btn btn-primary">Submit</button>
			</div>
		</div>
	</form>
	<hr>
	<?php
		if(isset($_GET['submit'])){
			$nim = $_GET['nim'];
			$matkul = $_GET['matkul'];
			$nilai = $_GET['nilai'];

			require_once ('class_nilai_mahasiswa.php');

			$nilai_mahasiswa = new NilaiMahasiswa($nim, $matkul, $nilai);

			echo 'NIM : '.$nilai_mahasiswa->nim;
			echo '<br>Nama Mata Kuliah : '.$nilai_mahasiswa->matakuliah;
			echo '<br>Nilai : '.$nilai_mahasiswa->nilai;
			echo '<br>Hasil Ujian : '.$nilai_mahasiswa->hasil();
			echo '<br>Grade: '.$nilai_mahasiswa->grade();

		}
	?>
	<!-- footer -->
	<hr>
	<div class="row">
		<div class="col-md-12">
			<address>
				 <strong>Lab Pemrograman Web Lanjutan</strong>
				 <br> Dosen: Sirojul Munir S.Si,M.Kom
				 <br> STT-NF - Kampus B
			</address>
		</div>
	</div>
</div>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
  </body>
</html>